<!--
		document.write("<noscript><iframe src=*.html></iframe></noscript>");
		function fun()
		{
			return false;
		}
		document.onselectstart=fun;	
	//-->